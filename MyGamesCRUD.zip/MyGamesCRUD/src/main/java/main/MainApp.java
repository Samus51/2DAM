package main;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import org.hibernate.Session;

import dao.*;

import models.*;

public class MainApp {

	public static void main(String[] args) {
		// Abro sesión
		Session session = HibernateUtil.getSession();

		try {
			// Insertar un grupo de plataformas
			System.out.println("Insertar grupo de plataformas");
			GruposPlataformaDaoImpl grupoPlataformasDao = new GruposPlataformaDaoImpl(session);
			GrupoPlataformas grupoConsolas = new GrupoPlataformas();
			grupoConsolas.setNombre("Consolas");
			grupoPlataformasDao.insert(grupoConsolas);
			System.out.println("-------------------");

			// Insertar plataformas dentro del grupo
			System.out.println("Insertar plataformas");
			PlataformaDaoImpl plataformaDao = new PlataformaDaoImpl(session);
			Plataforma ps5 = new Plataforma();
			ps5.setNombre("PlayStation 5");
			ps5.setGrupoPlataforma(grupoConsolas);
			plataformaDao.insert(ps5);

			Plataforma xbox = new Plataforma();
			xbox.setNombre("Xbox Series X");
			xbox.setGrupoPlataforma(grupoConsolas);
			plataformaDao.insert(xbox);
			System.out.println("-------------------");

			// Insertar un usuario
			System.out.println("Insertar usuario");
			UsuarioDaoImpl usuarioDao = new UsuarioDaoImpl(session);

			Usuario usuario = new Usuario();
			usuario.setNombre("Samuel Fernández");
			usuario.setEmail("samuel@example.com");
			usuario.setContrasena("contraseñaSegura123");
			usuario.setFechaRegistro(new Date());
			usuarioDao.insert(usuario);

			Usuario usuario2 = new Usuario();
			usuario2.setNombre("Jose Fernández");
			usuario2.setEmail("jose@example.com");
			usuario2.setContrasena("contraseñadebil123");
			usuario2.setFechaRegistro(new Date());
			usuarioDao.insert(usuario2);

			System.out.println("Usuarios insertados con éxito.");
			System.out.println("-------------------");

			// Insertar juegos
			System.out.println("Insertar juegos");

			JuegoDaoImpl juegoDao = new JuegoDaoImpl(session);
			DesarolladorDaoImpl devDao = new DesarolladorDaoImpl(session);
			GeneroDaoImpl genDao = new GeneroDaoImpl(session);

			// Crear desarrolladores
			Desarollador desarrollador1 = new Desarollador();
			desarrollador1.setNombre("Naughty Dog");
			devDao.insert(desarrollador1);

			Desarollador desarrollador2 = new Desarollador();
			desarrollador2.setNombre("343 Industries");
			devDao.insert(desarrollador2);

			// Crear géneros
			Genero genAccion = new Genero();
			genAccion.setNombre("Acción");
			genDao.insert(genAccion);

			Genero genAventura = new Genero();
			genAventura.setNombre("Aventura");
			genDao.insert(genAventura);

			// Crear la relación entre Usuario y Géneros Favoritos
			UsuarioGeneroFavoritoDaoImpl usuarioGeneroFavoritoDao = new UsuarioGeneroFavoritoDaoImpl(session);

			// Para el primer usuario (Samuel), establecer géneros favoritos
			UsuarioGeneroFavorito usuarioGeneroFavorito1 = new UsuarioGeneroFavorito();
			usuarioGeneroFavorito1.setUsuario(usuario);
			usuarioGeneroFavorito1.setGenero(genAccion);
			usuarioGeneroFavoritoDao.insert(usuarioGeneroFavorito1);

			UsuarioGeneroFavorito usuarioGeneroFavorito2 = new UsuarioGeneroFavorito();
			usuarioGeneroFavorito2.setUsuario(usuario);
			usuarioGeneroFavorito2.setGenero(genAventura);
			usuarioGeneroFavoritoDao.insert(usuarioGeneroFavorito2);

			// Para el segundo usuario (Jose), establecer géneros favoritos
			UsuarioGeneroFavorito usuarioGeneroFavorito3 = new UsuarioGeneroFavorito();
			usuarioGeneroFavorito3.setUsuario(usuario2);
			usuarioGeneroFavorito3.setGenero(genAventura);
			usuarioGeneroFavoritoDao.insert(usuarioGeneroFavorito3);

			// Insertar los juegos
			List<Genero> gens1 = new ArrayList<Genero>();
			gens1.add(genAventura);

			List<Genero> gens2 = new ArrayList<Genero>();
			gens2.add(genAccion);

			Juego juego1 = new Juego();
			juego1.setTitulo("The Last of Us Part II");
			juego1.setDescripcion("Un juego de acción y aventura.");
			juego1.setPlataforma(ps5);
			juego1.setCreadoPorUsuario(false);
			juego1.setDesarrollador(desarrollador1);
			juego1.setGeneros(gens1); // Añadir géneros
			juegoDao.insert(juego1);

			Juego juego2 = new Juego();
			juego2.setTitulo("Halo Infinite");
			juego2.setDescripcion("Un shooter en primera persona.");
			juego2.setPlataforma(xbox);
			juego2.setCreadoPorUsuario(false);
			juego2.setDesarrollador(desarrollador2);
			juego2.setGeneros(gens2); // Añadir género
			juegoDao.insert(juego2);

			// Crear la wishlist para los usuarios
			System.out.println("Crear wishlist para los usuarios");
			WishlistDaoImpl wishlistDao = new WishlistDaoImpl(session);

			Wishlist wishlist1 = new Wishlist();
			wishlist1.setUsuario(usuario);
			wishlist1.setJuegos(List.of(juego1)); // Añadir el juego a la wishlist
			wishlistDao.insert(wishlist1);

			Wishlist wishlist2 = new Wishlist();
			wishlist2.setUsuario(usuario2);
			wishlist2.setJuegos(List.of(juego2)); // Añadir el juego a la wishlist
			wishlistDao.insert(wishlist2);
			System.out.println("-------------------");

			// Mostrar todos los juegos de la wishlist de Samuel
			System.out.println("Mostrar todos los juegos de la wishlist de Samuel");
			List<Wishlist> wishlistDeSamuel = wishlistDao.searchByUsuario(usuario.getIdUsuario());
			for (Wishlist w : wishlistDeSamuel) {
				System.out.println("Juego en wishlist: " + w.getJuegos().get(0).getTitulo());
			}
			System.out.println("-------------------");

			// Mostrar todos los juegos de la wishlist de Jose
			System.out.println("Mostrar todos los juegos de la wishlist de Jose");
			List<Wishlist> wishlistDeJose = wishlistDao.searchByUsuario(usuario2.getIdUsuario());
			for (Wishlist w : wishlistDeJose) {
				System.out.println("Juego en wishlist: " + w.getJuegos().get(0).getTitulo());
			}
			System.out.println("-------------------");

			// Crear la biblioteca para los usuarios
			System.out.println("Crear biblioteca para los usuarios");
			BibliotecaDaoImpl biblioDao = new BibliotecaDaoImpl(session);

			Biblioteca b1 = new Biblioteca();
			b1.setUsuario(usuario);
			b1.setJuego(juego1);
			biblioDao.insert(b1);

			Biblioteca b2 = new Biblioteca();
			b2.setUsuario(usuario2);
			b2.setJuego(juego2);
			biblioDao.insert(b2);
			System.out.println("-------------------");

			// Mostrar todos los juegos de la biblioteca de Samuel
			System.out.println("Mostrar todos los juegos de la biblioteca de Samuel");
			List<Biblioteca> bibliotecaDeSamuel = biblioDao.searchByUsuario(usuario.getIdUsuario());
			for (Biblioteca b : bibliotecaDeSamuel) {
				System.out.println("Juego en biblioteca: " + b.getJuego().getTitulo());
			}
			System.out.println("-------------------");

			// Mostrar todos los juegos de la biblioteca de Jose
			System.out.println("Mostrar todos los juegos de la biblioteca de Jose");
			List<Biblioteca> bibliotecaDeJose = biblioDao.searchByUsuario(usuario2.getIdUsuario());
			for (Biblioteca b : bibliotecaDeJose) {
				System.out.println("Juego en biblioteca: " + b.getJuego().getTitulo());
			}
			System.out.println("-------------------");
		}

		catch (Exception e) {
			e.printStackTrace();
		} finally {
			HibernateUtil.closeSession();
		}
	}

}
