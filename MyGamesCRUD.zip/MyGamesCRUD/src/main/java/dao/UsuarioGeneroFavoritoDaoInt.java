package dao;

import models.UsuarioGeneroFavorito;

public interface UsuarioGeneroFavoritoDaoInt {
    void insert(UsuarioGeneroFavorito usuarioGeneroFavorito);
}
