package ad.swing;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

/**
 * film_id smallint UN AI PK title varchar(128) description text release_year
 * year
 */
public class MainApp {
	private static final String SQL_SELECT_ALL = "Select *, film_actor.*,film.* from actor \r\n"
			+ "inner join film_actor on film_actor.actor_id = actor.actor_id\r\n"
			+ "inner join film on film_actor.film_id = film.film_id;";

	public static void main(String[] args) {
		PantallaInicial pantalla = new PantallaInicial();
		pantalla.setVisible(true);
	}

}
