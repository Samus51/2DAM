package ad.swing;

import java.awt.EventQueue;
import java.awt.TextArea;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;
import java.awt.event.ActionListener;

public class PantallaInicial extends JFrame {
    private static final long serialVersionUID = 1L;

    private static final String SQL_SELECT_ALL = "SELECT film.film_id, film.title, film.release_year FROM film ORDER BY film.film_id;";
    private static final String SQL_SELECT_ACTORS_BY_FILM_ID = "SELECT actor.actor_id, actor.first_name, actor.last_name FROM actor INNER JOIN film_actor ON film_actor.actor_id = actor.actor_id INNER JOIN film ON film_actor.film_id = film.film_id WHERE film.film_id = ?;";
    
    private JPanel contentPane;
    private JTextField txtIdFilm;
    private JTextField txtTitle;
    private JTextField txtReleaseYear;
    private TextArea txtAreaActores;
    private ResultSet rs;


    public PantallaInicial() {
        initializeFrame();
        initializeComponents();
        initializeResultSet();
    }

    private void initializeFrame() {
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 540, 378);
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        setContentPane(contentPane);
        contentPane.setLayout(null);
    }

    private void initializeComponents() {
        txtIdFilm = new JTextField();
        txtIdFilm.setEditable(false);
        txtIdFilm.setBounds(15, 16, 86, 20);
        contentPane.add(txtIdFilm);

        txtTitle = new JTextField();
        txtTitle.setEditable(false);
        txtTitle.setBounds(15, 47, 86, 20);
        contentPane.add(txtTitle);

        txtReleaseYear = new JTextField();
        txtReleaseYear.setEditable(false);
        txtReleaseYear.setBounds(15, 73, 86, 20);
        contentPane.add(txtReleaseYear);

        JLabel lblIdFilm = new JLabel("Id_film");
        lblIdFilm.setBounds(119, 19, 32, 14);
        contentPane.add(lblIdFilm);

        JLabel lblTitle = new JLabel("Title");
        lblTitle.setBounds(119, 50, 20, 14);
        contentPane.add(lblTitle);

        JLabel lblYear = new JLabel("Year Release");
        lblYear.setBounds(119, 76, 63, 14);
        contentPane.add(lblYear);

        txtAreaActores = new TextArea();
        txtAreaActores.setEditable(false);
        txtAreaActores.setBounds(15, 104, 167, 100);
        contentPane.add(txtAreaActores);

        JLabel lblActors = new JLabel("Actors");
        lblActors.setBounds(188, 142, 63, 14);
        contentPane.add(lblActors);

        JButton btnPrimero = createNavigationButton("Primero", e -> mostrarDatos("primero"), 394, 15);
        JButton btnUltimo = createNavigationButton("Ultimo", e -> mostrarDatos("ultimo"), 394, 49);
        JButton btnSiguiente = createNavigationButton("Siguiente", e -> mostrarDatos("siguiente"), 394, 83);
        JButton btnAnterior = createNavigationButton("Anterior", e -> mostrarDatos("anterior"), 392, 117);

        JButton btnNueva = createActionButton("Nueva", e -> habilitarCampo(), 394, 168);
        JButton btnGuardar = createActionButton("Guardar", e -> nuevaPelicula(), 394, 210);

        contentPane.add(btnPrimero);
        contentPane.add(btnUltimo);
        contentPane.add(btnSiguiente);
        contentPane.add(btnAnterior);
        contentPane.add(btnNueva);
        contentPane.add(btnGuardar);
    }

    private JButton createNavigationButton(String text, ActionListener action, int x, int y) {
        JButton button = new JButton(text);
        button.setBounds(x, y, 69, 23);
        button.addActionListener(action);
        return button;
    }

    private JButton createActionButton(String text, ActionListener action, int x, int y) {
        JButton button = new JButton(text);
        button.setBounds(x, y, 69, 23);
        button.addActionListener(action);
        return button;
    }

    protected void habilitarCampo() {
        txtTitle.setEditable(true);
        txtReleaseYear.setEditable(true);
        txtAreaActores.setEditable(true);
        txtIdFilm.setText("");
    }

    private void insertarPelicula(String titulo, int releaseYear) {
        String sqlInsert = "INSERT INTO film (title, release_year, language_id) VALUES (?, ?, ?)";
        int languageId = 1;

        try (Connection conexion = Conector.conectar();
             PreparedStatement sentencia = conexion.prepareStatement(sqlInsert)) {

            sentencia.setString(1, titulo);
            sentencia.setInt(2, releaseYear);
            sentencia.setInt(3, languageId);
            int filasInsertadas = sentencia.executeUpdate();
            
            if (filasInsertadas > 0) {
                System.out.println("Película insertada con éxito.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    
    protected void nuevaPelicula() {
        String title = txtTitle.getText();
        String releaseYearText = txtReleaseYear.getText();

        if (title.isEmpty() || releaseYearText.isEmpty()) {
            JOptionPane.showMessageDialog(null, "Por favor, rellena todos los campos antes de guardar la película.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        int release_year;
        try {
            release_year = Integer.parseInt(releaseYearText);
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "El año de lanzamiento debe ser un número.", "Error de entrada", JOptionPane.ERROR_MESSAGE);
            return;
        }

        insertarPelicula(title, release_year);
        initializeResultSet();
        txtTitle.setText("");
        txtReleaseYear.setText("");
        txtAreaActores.setText("");

        txtTitle.setEditable(false);
        txtReleaseYear.setEditable(false);
        txtAreaActores.setEditable(false);
    }

    private void initializeResultSet() {
        try {
            Connection conexion = Conector.conectar();
            PreparedStatement sentencia = conexion.prepareStatement(SQL_SELECT_ALL, ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
            rs = sentencia.executeQuery();

            if (rs.last()) {
                int lastId = rs.getInt("film_id");
                System.out.println("Último ID de película: " + lastId);
                rs.beforeFirst();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void mostrarDatos(String accion) {
        try {
            switch (accion) {
                case "primero":
                    if (rs.first()) {
                        actualizarCampos();
                    }
                    break;
                case "ultimo":
                    if (rs.last()) {
                        actualizarCampos();
                    }
                    break;
                case "siguiente":
                    if (rs.next()) {
                        actualizarCampos();
                    }
                    break;
                case "anterior":
                    if (rs.previous()) {
                        actualizarCampos();
                    }
                    break;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void actualizarCampos() throws SQLException {
        int filmId = rs.getInt("film_id"); 
        txtIdFilm.setText(String.valueOf(filmId));
        txtReleaseYear.setText(String.valueOf(rs.getInt("release_year")));
        txtTitle.setText(rs.getString("title"));
        
        mostrarAllActores(filmId);
    }

    private void mostrarAllActores(int filmId) {
        StringBuilder actores = new StringBuilder();
        try {
            Connection conexion = Conector.conectar();
            PreparedStatement sentencia = conexion.prepareStatement(SQL_SELECT_ACTORS_BY_FILM_ID);
            sentencia.setInt(1, filmId);
            ResultSet rsActores = sentencia.executeQuery();

            while (rsActores.next()) {
                String nombreActor = rsActores.getString("first_name") + " " + rsActores.getString("last_name");
                actores.append(nombreActor).append("\n");
            }
            txtAreaActores.setText(actores.toString());
            rsActores.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
