package rawg.functions;

import org.json.JSONObject;

import utils.rawg.Developer;

import org.json.JSONArray;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URI;
import java.net.URL;

public class Sincronizador {

	// URL de la API con los parámetros necesarios
	private static final String API_URL_TEMPLATE = "https://api.rawg.io/api/games?key=fcc27fd8089c4a42a452702e7f522258&page_size=1&ordering=old&page=%d";

	public static void getJuegos() {
	    for (int i = 1; i <= 5; i++) { // Comienza en 1 porque las páginas empiezan desde 1 en la API
	        try {
	            // Conectar a la API con el número de página
	            String apiUrl = String.format(API_URL_TEMPLATE, i);
	            URL url = new URL(apiUrl);
	            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
	            connection.setRequestMethod("GET");

	            // Comprobar si la respuesta es correcta (200 OK)
	            if (connection.getResponseCode() == 200) {
	                // Leer la respuesta de la API
	                BufferedReader in = new BufferedReader(new InputStreamReader(connection.getInputStream()));
	                StringBuilder response = new StringBuilder();
	                String line;

	                while ((line = in.readLine()) != null) {
	                    response.append(line);
	                }
	                in.close();

	                // Convertir la respuesta a JSON
	                JSONObject json = new JSONObject(response.toString());
	                JSONArray results = json.getJSONArray("results");

	                // Procesar los juegos de la página actual
	                for (int j = 0; j < results.length(); j++) {
	                    JSONObject game = results.getJSONObject(j);

	                    // Obtener datos del juego
	                    String name = game.optString("name", "Nombre no disponible");
	                    String released = game.optString("released", "Fecha no disponible");
	                    String description = game.optString("description_raw", "Descripción no disponible");

	                    String esrb = "Clasificación no disponible";
	                    if (game.has("esrb_rating") && !game.isNull("esrb_rating")) {
	                        esrb = game.getJSONObject("esrb_rating").optString("name", "Clasificación no disponible");
	                    }

	                    // Obtener todas las plataformas
	                    StringBuilder platformsList = new StringBuilder();
	                    if (game.has("platforms") && game.get("platforms") instanceof JSONArray) {
	                        JSONArray platforms = game.getJSONArray("platforms");
	                        for (int k = 0; k < platforms.length(); k++) {
	                            JSONObject platformObj = platforms.getJSONObject(k).getJSONObject("platform");
	                            String platformName = platformObj.optString("name", "Plataforma desconocida");
	                            platformsList.append(platformName);
	                            if (k < platforms.length() - 1) {
	                                platformsList.append(", "); // Añadir coma entre plataformas
	                            }
	                        }
	                    } else {
	                        platformsList.append("Plataforma no disponible");
	                    }
	                    
	                    int idDesarrollador = -1; // Por ahora queda como no asignado
	                    String nombreDev = "Desarrollador no disponible"; // Valor por defecto

	                    if (game.has("developers") && game.get("developers") instanceof JSONArray) {
	                        JSONArray developers = game.optJSONArray("developers");
	                        
	                        if (developers != null && developers.length() > 0) {
	                            // Obtén el nombre del primer desarrollador
	                            nombreDev = developers.getJSONObject(0).optString("name", "Desarrollador no disponible").trim();
	                        }
	                    }

	                    // Imprime el nombre del desarrollador
	                    System.out.println("Nombre del desarrollador: " + nombreDev);


	                    
						
	                    StringBuilder imagesList = new StringBuilder();
	                    if (game.has("short_screenshots") && game.get("short_screenshots") instanceof JSONArray) {
	                        JSONArray screenshots = game.getJSONArray("short_screenshots");
	                        for (int k = 0; k < screenshots.length(); k++) {
	                            JSONObject imageObj = screenshots.getJSONObject(k); 
	                            String image = imageObj.optString("image", "Imagen no disponible");
	                            imagesList.append(image);
	                            if (k < screenshots.length() - 1) {
	                                imagesList.append(",\n "); // Añadir coma entre imágenes
	                            }
	                        }
	                    } else {
	                        imagesList.append("Imagen no disponible");
	                    }

						 
	                    
	                    // Imprimir los datos
	                    System.out.println("Nombre: " + name);
	                    System.out.println("Fecha de lanzamiento: " + released);
	                    System.out.println("Clasificación ESRB: " + esrb);
	                    System.out.println("Plataforma: " + platformsList.toString());
	                    System.out.println(description);
	                    System.out.println(results.toString());
	                    //  System.out.println("Lista de Imagenes: "+imagesList.toString());
	                    System.out.println("-----------------------");
	                }
	            } else {
	                System.out.println("Error al conectar con la API: " + connection.getResponseCode());
	            }
	        } catch (Exception e) {
	            e.printStackTrace();
	        }
	    }
	}

	// System.out.println("URLs de Imágenes: ");

	public static void main(String[] args) {
		getJuegos();
		
	}
}
